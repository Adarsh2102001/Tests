package com.demo.teststackqueue;
import javax.swing.event.ListDataListener;

import com.demo.stackqueue.*;
public class TestQueueList 
{
	public static void main(String args[])
	{
		QueueList qlist=new QueueList();
		qlist.enQueue(10);
		qlist.enQueue(20);
		qlist.enQueue(30);
		qlist.enQueue(40);
		qlist.enQueue(50);
		
		qlist.displayData();
		
		System.out.println("******* Dequeue  ***********");
		
		qlist.deQueue();
		qlist.displayData();
		
		
	}

}
